/**
 * \file
 *
 * \brief Microchip Interview Assignment Project
 *
 * Copyright (c) 2014-2015 Atmel Corporation. All rights reserved.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an
 *    Atmel microcontroller product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * \asf_license_stop
 *
 */

/**
 * \mainpage Starter Kit Demo
 *
 * \section Purpose
 *
 * The Starter Kit Demo will help new users get familiar with Atmel's
 * SAM family of microcontrollers. This demo features the IO1 and OLED1
 * extension boards for the SAM4 Xplained Pro.
 *
 * \section Requirements
 *
 * This package can be used with SAM Xplained Pro evaluation kits.
 *
 * \section Description
 *
 * The demonstration program can operate in 3 different modes; temperature
 * information, light sensor information and SD card status.
 * The user can switch between the various mode by pressing Button1.
 * When running in mode 3 (SD card content), the user can browse the SD
 * content using Button2 (previous) and Button3 (next). Filenames are directly
 * printed on the OLED screen.
 *
 * IO1 extension must be connected on EXT2.
 * OLED1 extension must be connected on EXT3.
 *
 */
/*
 * Support and FAQ: visit <a href="http://www.atmel.com/design-support/">Atmel Support</a>
 */

#include <asf.h>
#include <string.h>

/* These settings will force to set and refresh the operating mode. */
volatile uint32_t app_mode = 0;
volatile uint32_t app_mode_switch = 1;

#include "oled_uart_ph.h"
#define BUFFER_SIZE 128

#define UART_SERIAL_BAUDRATE     9600
#define UART_SERIAL_MODE         UART_MR_PAR_NO

#define PINS_UART1          (PIO_PB2A_URXD1 | PIO_PB3A_UTXD1)
#define PINS_UART1_FLAGS    (PIO_PERIPH_A | PIO_DEFAULT)
#define PINS_UART1_MASK     (PIO_PB2A_URXD1 | PIO_PB3A_UTXD1 )
#define PINS_UART1_PIO      PIOB        //Rx and Tx pins are in Parallel IO B
#define PINS_UART1_ID       ID_PIOB
#define PINS_UART1_TYPE     PIO_PERIPH_A  //UART1 is part of Peripheral A pg. 762 SAM4S Data sheet
#define PINS_UART1_ATTR     PIO_DEFAULT

const char  OLED1_Disp_Name[] = "Subramani C";
const char  OLED1_Disp_Company[] = "Microchip";

/**************************************************************************/
//  OLED1_Display_Task - function to display the string to the OLED1 screen
//  input: string to print on the screen
//  output: print the string to OLED1
/**************************************************************************/
static void OLED1_Display_Task(void)
{
	// set the cursor to line 1 of the OLED1
	ssd1306_set_page_address(1);
	
	// set the cursor to column 1 of the OLED1
    ssd1306_set_column_address(0);
	
	/* Display the OLED with the Start-up text */	
    ssd1306_write_text(OLED1_Disp_Name);
	
	//Wait for some time 
	delay_ms(50);

	// set the cursor to line 2 of the OLED1
	ssd1306_set_page_address(2);
	
	// set the cursor to column 1 of the OLED1
    ssd1306_set_column_address(0);
	
	/* Display the OLED with the Start-up text */	
    ssd1306_write_text(OLED1_Disp_Company);	
	
	//Wait for some time 
	delay_ms(50);
	
	//notify the terminal user to read the OLED1 display
    string_to_uart1_terminal("\r\nCheck the OLED1 Screen!");	
} 

/******************************************************************************/
//  uart_string_to_terminal - function to print the string to the uart terminal
//  input: string value to print
//  output: print the string to the terminal
/******************************************************************************/
static void string_to_uart1_terminal(const char * str) 
{
    // print string to the uart terminal on UART1
	while (*str) 
	{
        usart_serial_putchar(UART1, *str++);
    }
}

/******************************************************************************/
//  Serial_Receive_Num - function to receive stream of data from terminal
//  input: buffer to store the data, length of data
//  output: Number of data received from terminal 
/******************************************************************************/
unsigned int Serial_Receive_Num(char *buffer, unsigned int max_size)
{
    unsigned int num_char = 0;
	char rval = 0;
 
    /* Wait for and store incoming data until either a carriage return is received
     *   or the number of received characters (num_chars) exceeds max_size */
    while(num_char < max_size)
    {
        
		RVAL: usart_serial_getchar(UART1, &rval);   // wait until data available in RX buffer
        
	    // insert nul character to indicate end of string
        if( rval == '\r'){
            *buffer = '\0';     
            break;
        }		
		// Validate the received data to be of numbers
		if(num_char < max_size){
			if((rval >= (char)0x30) && (rval <=(char)0x39)) 
			{ *buffer = rval; }
			else { string_to_uart1_terminal("\r\nEnter only number:"); 
			goto RVAL; }
		}

        buffer++;
        num_char++;
    }
    *buffer = '\0';  
    return num_char;
}

/***************************************************************************/
//  Terminal_Display_Task - function to display string to Terminal
//  input: string value
//  output: print the string to the terminal
/***************************************************************************/
static void Terminal_Display_Task(void)
{
	/* Print name in the first line */
	string_to_uart1_terminal("\r\n");
	string_to_uart1_terminal(OLED1_Disp_Name);
	
	
	/* Print name in the second line */
	string_to_uart1_terminal("\r\n");
	string_to_uart1_terminal(OLED1_Disp_Company);
		
}

/*********************************************************************************/
//  Swap_Variable_Task - function to swap to variable without using extra variable
//  input: 8bit value  from terminal
//  output: result of bits in the byte value
/***********************************************************************************/
static void Swap_Variable_Task(void)
{
  unsigned int Var_A = 0;
  unsigned int Var_B = 0;
  
  char Rval[5];
  char Pval[5];
 
  string_to_uart1_terminal("\r\nSwap two variables without using extra variable");

  string_to_uart1_terminal("\r\nEnter Integer Number 1:");

  (void)Serial_Receive_Num(Rval,2);
  Var_A = atoi(Rval); // convert to integer number

  string_to_uart1_terminal("\r\nEnter integer Number 2:");

  (void)Serial_Receive_Num(Rval,2);
  Var_B = atoi(Rval);  // convert to integer number

  // Code to swap 'Var_A' and 'Var_B 
  Var_A = Var_A ^ Var_B;  // Var_A now becomes 9
  Var_B = Var_A ^ Var_B;  // Var_B becomes 2
  Var_A = Var_A ^ Var_B;  // Var_A becomes 7
  
  string_to_uart1_terminal("\r\nSwapped values:");
  itoa(Var_A, Pval, 10); // convert to char string
  string_to_uart1_terminal(Pval);
  
  itoa(Var_B, Pval, 10); // convert to char string
  usart_serial_putchar(UART1, ','); 
  string_to_uart1_terminal(Pval);  
	
}

/*************************************************************************/
//  Count_Num_Bits_Task - function to count the number of bits in a byte
//  input: 8bit value  from terminal
//  output: result of bits in the byte value
/*************************************************************************/
static void Count_Num_Bits_Task(void)
{
  unsigned int Count_Bits = 0;
  unsigned int ByteSize_Val = 0;
  char Rval2[10];
  char Pval2[10];
  
  string_to_uart1_terminal("\r\nCount Number of Bits in a Byte");
  string_to_uart1_terminal("\r\nEnter Integer Number:");

  (void)Serial_Receive_Num(Rval2,2);
  ByteSize_Val = atoi(Rval2);  // convert to integer number
  
  while(ByteSize_Val)
  {
    Count_Bits += ByteSize_Val & 1;
    ByteSize_Val >>= 1;
  }
  
  string_to_uart1_terminal("\r\nNumber of bits: ");
  itoa(Count_Bits, Pval2, 10); // convert to char string
  string_to_uart1_terminal(Pval2); 
	
}
/**********************************************************************/
//  Test_Bit_Task - function to test the nth bits in a 32bit variable
//  input: 32bit value and bit position from terminal
//  output: result of the nth bit true = if set else false
/*********************************************************************/
static void Test_Bit_Task(void)
{
  uint32_t WordSize_Val;
  unsigned int  Position;
  unsigned int  Result;
  char Rval3[10];
  char Pval3[10];
  
  string_to_uart1_terminal("\r\nTest n-th Bit in a Byte");
  string_to_uart1_terminal("\r\nEnter 8digit Integer Number:");

  (void)Serial_Receive_Num(Rval3,8);
  WordSize_Val = atoi(Rval3);  // convert to integer number  

  string_to_uart1_terminal("\r\nEnter the bit position(32bit):");

  (void)Serial_Receive_Num(Rval3,2);
  Position = atoi(Rval3);  // convert to integer number    

  Result = ((WordSize_Val >> Position) & 1);
  itoa(Position,Pval3,10);
  string_to_uart1_terminal("\r\n");
  string_to_uart1_terminal(Pval3);
  string_to_uart1_terminal("\r\n-Bit Position is:");
  
  if (Result & 1)
  {
	  string_to_uart1_terminal(" SET");
  }
  else
  {
	  string_to_uart1_terminal(" NOT SET");
  }
	
}

/**********************************************************************/
//  Calculate_CRC16_Task - function to calculate CRC-16
//  input: 32bit value and bit position from terminal
//  output: CRC-26 value
/*********************************************************************/
static void Calculate_CRC16_Task(void)
{
  uint16_t CRC_Val;
  char Rval4[10];
  char Pval4[10];
  
  // Receive the Inputs from Terminal 
  string_to_uart1_terminal("\r\nCRC-16 Calculation");
  string_to_uart1_terminal("\r\nEnter 8digit Integer Number:");

  (void)Serial_Receive_Num(Rval4,8);
  
  CRC_Val = GENERATE_CRC_16(Rval4,8); // calculate CRC-16
  
  string_to_uart1_terminal("\r\nCRC-16 Value:0x");

  itoa(CRC_Val, Pval4, 16); // convert to char string
  
  string_to_uart1_terminal(Pval4); 
  
}

/* Main routine for the OLED1 and UART Display Application */
int main(void)
{
	// Initialize clocks.
	sysclk_init();

	// Initialize GPIO states.
	board_init();

	// Configure ADC for light sensor.
	configure_adc();

	// configure  serial USART    
   pio_configure(PINS_UART1_PIO, PINS_UART1_TYPE, PINS_UART1_MASK, PINS_UART1_ATTR);
   pmc_enable_periph_clk(ID_UART1);
   
   sam_uart_opt_t uart1_sett =
   { sysclk_get_cpu_hz(), UART_SERIAL_BAUDRATE, UART_SERIAL_MODE };
   
   // Initialize serial UART COM
   uart_init(UART1,&uart1_sett);
   
	// Configure I/O buttons.
	configure_buttons();

	// Initialize SPI and SSD1306 controller to drive the OLED1 display.
	ssd1306_init();
	ssd1306_clear();

/*************************************************************************/
//    TASK_01: Print "Subramani C and Microchip" OLED1 Display at start-up
/*************************************************************************/
	
	// set the cursor to line 1 of the OLED1
	ssd1306_set_page_address(0);
	
	// set the cursor to column 1 of the OLED1
    ssd1306_set_column_address(0);
	
	/* Display the OLED with the Start-up text */	
    ssd1306_write_text(OLED1_Disp_Name);
	
	//the ASF includes handy delay functions
	delay_ms(50);

	// set the cursor to line 2 of the OLED1
	ssd1306_set_page_address(1);
	
	// set the cursor to column 1 of the OLED1
    ssd1306_set_column_address(0);
	
	/* Display the OLED with the Start-up text */	
    ssd1306_write_text(OLED1_Disp_Company);

    //notify the terminal: Button menu option
    string_to_uart1_terminal("\r\nPress Button 1 for next options!");	
	
	//the ASF includes handy delay functions
	delay_ms(3000);		

	while (true)
	{
		/* Refresh page title only if necessary. */
		if (app_mode_switch > 0)
		{
			app_mode = (app_mode + 1);
			
			/* Clear the last screen. */
			ssd1306_clear();
			ssd1306_set_page_address(0);
			ssd1306_set_column_address(0);

			/* Operating mode section switch */
			switch(app_mode)
			{
				case TASK_1: // Display Name and company to the OLED1 screen
				{				
					ioport_set_pin_level(IO1_LED1_PIN, IO1_LED1_ACTIVE);
					ioport_set_pin_level(IO1_LED2_PIN, !IO1_LED2_ACTIVE);
					ioport_set_pin_level(IO1_LED3_PIN, !IO1_LED3_ACTIVE);
					ssd1306_write_text("Task1: OLED1 Display ");
					OLED1_Display_Task();
				}
				break;
				
				case TASK_2: // Display Name and company to the UART1 Terminal
				{				
					ioport_set_pin_level(IO1_LED1_PIN, !IO1_LED1_ACTIVE);
					ioport_set_pin_level(IO1_LED2_PIN, IO1_LED2_ACTIVE);
					ioport_set_pin_level(IO1_LED3_PIN, !IO1_LED3_ACTIVE);
					ssd1306_write_text("Task2: Terminal Display");
					Terminal_Display_Task();
				}				
				break;

				case TASK_3:
				{				
					ioport_set_pin_level(IO1_LED1_PIN, !IO1_LED1_ACTIVE);
					ioport_set_pin_level(IO1_LED2_PIN, !IO1_LED2_ACTIVE);
					ioport_set_pin_level(IO1_LED3_PIN, IO1_LED3_ACTIVE);
					ssd1306_write_text("Task3: Swap Variable");
					Swap_Variable_Task();
				}				
				break;

				case TASK_4:
				{				
					ioport_set_pin_level(IO1_LED1_PIN, IO1_LED1_ACTIVE);
					ioport_set_pin_level(IO1_LED2_PIN, !IO1_LED2_ACTIVE);
					ioport_set_pin_level(IO1_LED3_PIN, !IO1_LED3_ACTIVE);
					ssd1306_write_text("Task4: Count the Bits");
					Count_Num_Bits_Task();
				}				
				break;

				case TASK_5:
				{				
					ioport_set_pin_level(IO1_LED1_PIN, !IO1_LED1_ACTIVE);
					ioport_set_pin_level(IO1_LED2_PIN, IO1_LED2_ACTIVE);
					ioport_set_pin_level(IO1_LED3_PIN, !IO1_LED3_ACTIVE);
					ssd1306_write_text("Task5: Test the Bits");
					Test_Bit_Task();
				}				
				break;

				case TASK_6:
				{				
					ioport_set_pin_level(IO1_LED1_PIN, !IO1_LED1_ACTIVE);
					ioport_set_pin_level(IO1_LED2_PIN, !IO1_LED2_ACTIVE);
					ioport_set_pin_level(IO1_LED3_PIN, IO1_LED3_ACTIVE);
					ssd1306_write_text("Task6: CRC-16 Calculation");
					Calculate_CRC16_Task();
				}		
				break;	
				
				default:
				/* set to re-start the tasks, since nothing else to do. */
				{				
					app_mode = 0;
					ioport_set_pin_level(IO1_LED1_PIN, !IO1_LED1_ACTIVE);
					ioport_set_pin_level(IO1_LED2_PIN, !IO1_LED2_ACTIVE);
					ioport_set_pin_level(IO1_LED3_PIN, !IO1_LED3_ACTIVE);					
				}					
				
				break;
			}			
			
			if(app_mode > TASK_6)
			{
				app_mode_switch = 1;
			}
			else
			{
				app_mode_switch = 0;
			}
		}		

     	/* Wait and stop screen flickers. */
		delay_ms(100);
	}
}

/**********************************************************************/
//  GENERATE_CRC_16 - function to calculate the CRC-16 value
//  input: 32bit value and length of the data
//  output: result of the nth bit true = if set else false
/*********************************************************************/
unsigned short GENERATE_CRC_16(const unsigned char* data_p, unsigned char length)
{
    unsigned char x;
    unsigned short crc = 0xFFFF;

    while (length--){
        x = crc >> 8 ^ *data_p++;
        x ^= x>>4;
        crc = (crc << 8) ^ ((unsigned short)(x << 12)) ^ ((unsigned short)(x <<5)) ^ ((unsigned short)x);
    }
    return crc;
}


/******************************************************************/
//  End of the File
//  Date Modified: 16/02/2017
//  Modified By: Subramani C
//  Version Number: 1.0
/******************************************************************/
